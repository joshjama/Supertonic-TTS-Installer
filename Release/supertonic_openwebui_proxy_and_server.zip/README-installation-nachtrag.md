## Speech-Dispatcher Konfiguration 

Dieser Abschnitt ergänzt die bestehende README. Du brauchst das Projektverzeichnis mit `speechd_ai_wrapper`, `speechd_ai.conf`, dem bereits mitgelieferten Installationsskript und `show-speechd-ai-addmodule.sh`. Dein OpenAI-kompatibler TTS-Server muss erreichbar sein.

### Installation

1. Führe im Projektverzeichnis das **bereits mitgelieferte Installationsskript** aus, wie im bisherigen Teil der README beschrieben.
* Führe im speech-dispatcher - verzeichniss ebenfalls den installer aus. 
$ bash cd speech-dispatcher/ && \
$ ./install_speechd_ai.sh 

2. Trage in `speechd_ai.conf` die Adresse deines TTS-Endpunkts sowie Modell und Standardstimme ein. Wenn diese Werte schon stimmen, musst du nichts ändern.
3. Lass dir im Projektverzeichnis die passende Modulzeile ausgeben:
   ```bash
$   bash cd ./speech-dispatcher && ./show-speechd-ai-addmodule.sh
   ```
4. Kopiere die **tatsächlich ausgegebene** `AddModule "ai" ...`-Zeile unter die anderen `AddModule`-Zeilen in deine verwendete Speech-Dispatcher-Konfiguration. Systemweit ist das normalerweise `/etc/speech-dispatcher/speechd.conf`; gegebenenfalls wird stattdessen `~/.config/speech-dispatcher/speechd.conf` verwendet. Verschiebe das Projekt danach nicht, ohne die Pfade in der Zeile zu aktualisieren.
5. **Starte Speech Dispatcher neu**, damit die neue Zeile geladen wird:

   ```bash
$   systemctl --user restart speech-dispatcher.service
   ```

6. Prüfe, ob `ai` erscheint und spricht:

   ```bash
$   spd-say -O
$   spd-say -o ai "Test der Sprachausgabe"
   ```

Das Hilfsskript zeigt die Zeile lediglich an; es trägt sie nicht selbst ein. Für Änderungen an der systemweiten Konfiguration sind Administratorrechte nötig.

### Mehrere feste Stimmen einrichten

Wenn du ohne die noch nicht zuverlässig funktionierende Stimmenliste verschiedene Supertonic-Stimmen verwenden möchtest, kannst du **pro Stimme ein eigenes Speech-Dispatcher-Modul** eintragen. Es verwendet jeweils denselben Wrapper, aber eine eigene Kopie von `speechd_ai.conf` mit anderem `DefaultVoice`-Wert. So wählst du in Orca das Modul statt einer Stimme aus dessen Stimmenliste.

Beispiel für zwei Stimmen: Belasse `speechd_ai.conf` mit `DefaultVoice F1`, kopiere sie nach `speechd_ai-f2.conf` und ändere **in der Kopie** die Zeile zu `DefaultVoice F2`:

```bash
cp speechd_ai.conf speechd_ai-f2.conf
```

Nutze die vom Hilfsskript erzeugte `AddModule`-Zeile zweimal. Lasse die erste Zeile unverändert. In der zweiten ändere nur den Modulnamen zu `ai-f2` und den Pfad der Konfigurationsdatei zu `speechd_ai-f2.conf`; der absolute Wrapper-Pfad bleibt gleich. Das sieht **schematisch** so aus – ersetze die Beispielpfade durch die absoluten Pfade aus deiner Ausgabe:

```text
AddModule "ai" "/ABSOLUTER/PROJEKTPFAD/speechd_ai_wrapper" "/ABSOLUTER/PROJEKTPFAD/speechd_ai.conf"
AddModule "ai-f2" "/ABSOLUTER/PROJEKTPFAD/speechd_ai_wrapper" "/ABSOLUTER/PROJEKTPFAD/speechd_ai-f2.conf"
```

Nach einem Neustart sollten `ai` und `ai-f2` in `spd-say -O` erscheinen. Teste die zweite Variante mit `spd-say -o ai-f2 "Test mit F2"`. Für weitere Stimmen wiederholst du das Kopieren und gibst jeder Konfigurationsdatei und jedem Modul einen **eindeutigen** Namen. Dieses Verfahren benötigt keine dynamische Stimmenliste und fragt den TTS-Proxy nicht nach verfügbaren Stimmen.

Supertonic stellt diese zehn eingebauten Stimmen bereit ([Stimmenübersicht](https://supertone-inc.github.io/supertonic-py/voices/)):

| Weibliche Stimmen | Männliche Stimmen |
| --- | --- |
| `F1` | `M1` |
| `F2` | `M2` |
| `F3` | `M3` |
| `F4` | `M4` |
| `F5` | `M5` |

Die Namen sind die Werte für `DefaultVoice`. Ob dein **konkreter** OpenAI-kompatibler Proxy sie unverändert annimmt, lässt sich mit dem jeweiligen `spd-say -o MODULNAME`-Test prüfen.

### Wichtig bei Verwendung von Orca

Beim Neustart von Speech Dispatcher **kann die Sprachausgabe vorübergehend still bleiben**, insbesondere bei einem Konfigurationsfehler. Richte am besten **vorher ein zweites Orca-Profil mit einem bereits funktionierenden Sprachausgabemodul** ein. Weise in Orcas Tastenbelegungen dem Befehl **„Zum nächsten Profil wechseln“** eine gut erreichbare Tastenkombination zu und teste sie, solange die Sprachausgabe noch funktioniert. Der Befehl ist standardmäßig nicht belegt ([Orca-Profilbefehle](https://help.gnome.org/users/orca/stable/commands_profiles.html.en)). Ein zweites Profil erleichtert den Wechsel zurück, garantiert aber keine Sprachausgabe, falls Speech Dispatcher insgesamt ausfällt.

Die Stimmenliste innerhalb eines einzelnen `ai`-Moduls ist derzeit noch nicht verlässlich implementiert. Prüfe zuerst die **Modulliste** mit `spd-say -O`, nicht die Stimmenliste mit `spd-say -o ai -L`. Das Python-Modul schreibt ein eigenes Log nach `${TMPDIR:-/tmp}/speechd_ai.log`; veröffentliche daraus keine vertraulichen Texte oder Zugangsdaten.
